# SeleniumDataDrivenTest-JSON

Find the codes for data driven testing in selenium using JSON   
Youtube Video: https://youtu.be/K_nQyySRHEw
